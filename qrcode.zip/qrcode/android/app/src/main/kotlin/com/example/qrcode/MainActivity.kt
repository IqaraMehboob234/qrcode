package com.example.qrcode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
